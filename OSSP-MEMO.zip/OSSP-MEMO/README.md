# Memo
a little memo on android device <br>
` alarm clock `  can be added to each memo <br>
Some screenshots are shown as below: <br>
![](https://github.com/SFZhang26/Memo/raw/master/intro_pic/main.JPG)
![](https://github.com/SFZhang26/Memo/raw/master/intro_pic/main2.JPG)  
![](https://github.com/SFZhang26/Memo/raw/master/intro_pic/memo1.JPG)  
![](https://github.com/SFZhang26/Memo/raw/master/intro_pic/memo2.JPG)  
![](https://github.com/SFZhang26/Memo/raw/master/intro_pic/notice1.JPG)  
